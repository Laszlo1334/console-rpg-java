package com.education.spells;

import com.education.units.Unit;

public interface Spell {
    String cast(MagicCaster caster, Unit target);
    String getName();
}
