package com.education.spells;

import com.education.units.Unit;

public class FireBallSpell implements Spell {
    @Override
    public String cast(MagicCaster caster, Unit target) {
        return "Casting Fireball!";
    }

    @Override
    public String getName() {
        return "Fireball";
    }
}
