package com.education.spells;

import com.education.combat.targeting.TargetStrategy;
import com.education.core.effects.instant.HealInstant;
import com.education.units.Unit;

public class HealSpell  implements Spell{
    private final int manaCost;
    private final TargetStrategy targetStrategy;

    public HealSpell(int manaCost, TargetStrategy targetStrategy) {
        this.manaCost = manaCost;
        this.targetStrategy = targetStrategy;
    }

    @Override
    public String cast(MagicCaster caster, Unit target) {
        HealInstant healEffect = new HealInstant( 30);
        healEffect.apply(target);
        return "Casting Heal Spell!";
    }

    @Override
    public String getName() {
        return "Heal";
    }


    public int getManaCost() {
        return manaCost;
    }

    public TargetStrategy getTargetStrategy() {
        return targetStrategy;
    }
}
